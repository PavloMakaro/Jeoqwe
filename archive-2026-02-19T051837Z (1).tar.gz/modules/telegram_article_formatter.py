#!/usr/bin/env python3
"""
Модуль для форматирования статей в Telegram-формат
"""

def format_telegram_article(title, content_dict):
    """
    Форматирует статью для Telegram
    
    Args:
        title (str): Заголовок статьи
        content_dict (dict): Словарь с разделами статьи
        
    Returns:
        str: Отформатированная статья
    """
    # Эмодзи для оформления
    emojis = {
        'title': '🎮',
        'info': 'ℹ️',
        'career': '📈',
        'achievements': '🏆',
        'stats': '📊',
        'style': '🎯',
        'conclusion': '✨'
    }
    
    # Начинаем формировать статью
    article = f"{emojis['title']} <b>{title}</b>\n\n"
    
    # Добавляем разделы
    for section, content in content_dict.items():
        if section == 'basic_info':
            article += f"{emojis['info']} <b>Основная информация:</b>\n"
            for key, value in content.items():
                article += f"• <b>{key}:</b> {value}\n"
            article += "\n"
        
        elif section == 'career':
            article += f"{emojis['career']} <b>Карьерный путь:</b>\n"
            for item in content:
                article += f"• {item}\n"
            article += "\n"
        
        elif section == 'achievements':
            article += f"{emojis['achievements']} <b>Достижения:</b>\n"
            for item in content:
                article += f"• {item}\n"
            article += "\n"
        
        elif section == 'stats':
            article += f"{emojis['stats']} <b>Статистика:</b>\n"
            for key, value in content.items():
                article += f"• <b>{key}:</b> {value}\n"
            article += "\n"
        
        elif section == 'playing_style':
            article += f"{emojis['style']} <b>Игровой стиль:</b>\n"
            for item in content:
                article += f"• {item}\n"
            article += "\n"
        
        elif section == 'conclusion':
            article += f"{emojis['conclusion']} <b>Заключение:</b>\n"
            article += f"{content}\n"
    
    # Добавляем хештеги
    article += "\n\n"
    article += "#Cobrazera #CS2 #TheMongolZ #Монголия #Киберспорт #CounterStrike"
    
    return article

def create_cobrazera_article():
    """Создает статью о Cobrazera"""
    
    content = {
        'basic_info': {
            'Полное имя': 'Анарбилег Ууганбаяр',
            'Никнейм': 'Cobrazera',
            'Дата рождения': '3 августа 2005 года',
            'Национальность': 'Монголия',
            'Текущая команда': 'The MongolZ',
            'Позиция': 'Rifler',
            'Игра': 'Counter-Strike 2'
        },
        
        'career': [
            'Начал карьеру в 2024 году в команде The Huns',
            'В 2025 году перешел в The MongolZ',
            'Участвует в международных турнирах с 2024 года'
        ],
        
        'achievements': [
            'MESA Pro Series Spring 2025 — 1 место ($1,100)',
            'ESL Challenger League Season 49: Asia — 3 место ($1,000)',
            'IESF World Championship 2024 — 5-8 место ($2,500)',
            'Asian Champions League 2025 — 5-6 место ($2,400)'
        ],
        
        'stats': {
            'Общий заработок': '$8,290',
            'Количество турниров': '6',
            'Рейтинг в Монголии': '#81',
            'Заработок в 2024': '$2,790',
            'Заработок в 2025': '$5,500'
        },
        
        'playing_style': [
            'Специализация: rifler (винтовки)',
            'Возраст: 19 лет — большой потенциал роста',
            'Быстрая адаптация к новой команде',
            'Стабильные выступления на турнирах'
        ],
        
        'conclusion': 'Анарбилег "Cobrazera" Ууганбаяр — восходящая звезда монгольского CS2. В возрасте 19 лет он уже показывает стабильные результаты на международной арене в составе The MongolZ. Его переход в топовую монгольскую команду и регулярные выступления на турнирах различного уровня свидетельствуют о серьезном подходе к карьере. Cobrazera представляет новое поколение монгольских киберспортсменов, которые укрепляют позиции региона на мировой арене.'
    }
    
    return format_telegram_article("Анарбилег 'Cobrazera' Ууганбаяр: Будущее монгольского CS2", content)

if __name__ == "__main__":
    article = create_cobrazera_article()
    print(article)