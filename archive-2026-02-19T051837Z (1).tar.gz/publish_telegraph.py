#!/usr/bin/env python3
"""
Скрипт для публикации статьи на Telegra.ph
"""

import requests
import json

class TelegraphPublisher:
    """Класс для работы с Telegra.ph API"""
    
    BASE_URL = "https://api.telegra.ph"
    
    def __init__(self, access_token: str):
        """
        Инициализация издателя Telegra.ph
        
        Args:
            access_token: Токен доступа Telegra.ph
        """
        self.access_token = access_token
        self.session = requests.Session()
    
    def create_page(
        self, 
        title: str, 
        content: str, 
        author_name: str = "", 
        author_url: str = "",
        return_content: bool = False
    ) -> dict:
        """
        Создание страницы (статьи) на Telegra.ph
        
        Args:
            title: Заголовок статьи
            content: Содержимое статьи в формате HTML
            author_name: Имя автора (опционально)
            author_url: URL автора (опционально)
            return_content: Возвращать ли содержимое в ответе
            
        Returns:
            Словарь с данными созданной страницы, включая URL
        """
        if not self.access_token:
            raise ValueError("Access token is required for creating pages")
        
        url = f"{self.BASE_URL}/createPage"
        params = {
            "access_token": self.access_token,
            "title": title,
            "content": content,
            "author_name": author_name,
            "author_url": author_url,
            "return_content": "true" if return_content else "false"
        }
        
        response = self.session.get(url, params=params)
        return response.json()

def main():
    """Основная функция"""
    
    # Ваш access_token
    access_token = "936f5b8d90b8876cf9bc115a69e8738797f92f14d67a00018929ea91defd"
    
    # HTML-контент статьи о Cobrazera
    html_content = '''[
        {"tag":"h1","children":["Анарбилег \\"Cobrazera\\" Ууганбаяр: Восходящая звезда монгольского CS2"]},
        {"tag":"h2","children":["Основная информация"]},
        {"tag":"p","children":[
            {"tag":"strong","children":["Полное имя:"]}," Анарбилег Ууганбаяр",
            {"tag":"br"},
            {"tag":"strong","children":["Никнейм:"]}," Cobrazera",
            {"tag":"br"},
            {"tag":"strong","children":["Дата рождения:"]}," 3 августа 2005 года",
            {"tag":"br"},
            {"tag":"strong","children":["Национальность:"]}," Монголия",
            {"tag":"br"},
            {"tag":"strong","children":["Текущая команда:"]}," The MongolZ",
            {"tag":"br"},
            {"tag":"strong","children":["Позиция:"]}," Rifler",
            {"tag":"br"},
            {"tag":"strong","children":["Игра:"]}," Counter-Strike 2"
        ]},
        {"tag":"h2","children":["Карьерный путь"]},
        {"tag":"h3","children":["Ранние годы"]},
        {"tag":"p","children":["Cobrazera начал свою профессиональную карьеру в 2024 году. До прихода в The MongolZ он играл за команду The Huns, где проявил себя как перспективный молодой игрок."]},
        {"tag":"h3","children":["Переход в The MongolZ"]},
        {"tag":"p","children":["В 2025 году состоялся его переход в The MongolZ — ведущую монгольскую киберспортивную организацию. Этот переход стал важным этапом в его карьере, открыв доступ к более серьезным турнирам и международной арене."]},
        {"tag":"h2","children":["Достижения и статистика"]},
        {"tag":"h3","children":["Призовые деньги"]},
        {"tag":"ul","children":[
            {"tag":"li","children":[{"tag":"strong","children":["Общий заработок:"]}," $8,290 (по данным Esports Earnings)"]},
            {"tag":"li","children":[{"tag":"strong","children":["Количество турниров:"]}," 6"]},
            {"tag":"li","children":[{"tag":"strong","children":["Рейтинг в Монголии:"]}," #81"]}
        ]},
        {"tag":"h3","children":["Ключевые турниры"]},
        {"tag":"ol","children":[
            {"tag":"li","children":[{"tag":"strong","children":["IESF World Championship 2024 (CS2)"]}," — 5-8 место, $2,500"]},
            {"tag":"li","children":[{"tag":"strong","children":["Asian Champions League 2025"]}," — 5-6 место, $2,400"]},
            {"tag":"li","children":[{"tag":"strong","children":["MESA Pro Series Spring 2025"]}," — 1 место, $1,100"]},
            {"tag":"li","children":[{"tag":"strong","children":["BLAST Open Spring 2025"]}," — 13-16 место, $1,000"]},
            {"tag":"li","children":[{"tag":"strong","children":["ESL Challenger League Season 49: Asia"]}," — 3 место, $1,000"]}
        ]},
        {"tag":"h3","children":["Распределение по годам"]},
        {"tag":"ul","children":[
            {"tag":"li","children":[{"tag":"strong","children":["2024 год:"]}," $2,790 (2 турнира)"]},
            {"tag":"li","children":[{"tag":"strong","children":["2025 год:"]}," $5,500 (4 турнира)"]}
        ]},
        {"tag":"h2","children":["Игровой стиль и особенности"]},
        {"tag":"h3","children":["Позиция и роль"]},
        {"tag":"p","children":["Cobrazera играет на позиции rifler, что означает его специализацию на использовании винтовок (AK-47, M4A4). Эта позиция требует отличной точности, позиционирования и принятия быстрых решений."]},
        {"tag":"h3","children":["Сильные стороны"]},
        {"tag":"ol","children":[
            {"tag":"li","children":[{"tag":"strong","children":["Молодой возраст"]}," — 19 лет, что дает большой потенциал для роста"]},
            {"tag":"li","children":[{"tag":"strong","children":["Быстрая адаптация"]}," — успешный переход в топовую монгольскую команду"]},
            {"tag":"li","children":[{"tag":"strong","children":["Стабильность"]}," — регулярные выступления на турнирах различного уровня"]}
        ]},
        {"tag":"h2","children":["Значение для монгольской сцены"]},
        {"tag":"h3","children":["Развитие региона"]},
        {"tag":"p","children":["Cobrazera является частью нового поколения монгольских киберспортсменов, которые поднимают уровень региона на международной арене. The MongolZ уже доказали свою конкурентоспособность на азиатской сцене, и такие игроки как Cobrazera укрепляют позиции команды."]},
        {"tag":"h3","children":["Перспективы"]},
        {"tag":"p","children":["С учетом его возраста и текущего прогресса, Cobrazera имеет все шансы стать одним из ключевых игроков не только монгольской, но и азиатской сцены CS2 в ближайшие годы."]},
        {"tag":"h2","children":["Технические детали"]},
        {"tag":"h3","children":["Оборудование и настройки"]},
        {"tag":"p","children":["Информация о конкретном оборудовании и игровых настройках Cobrazera пока не широко доступна, что характерно для молодых игроков, которые только начинают привлекать внимание медиа."]},
        {"tag":"h3","children":["Статистика HLTV"]},
        {"tag":"p","children":["По данным HLTV, его профиль был создан под ID 23402, что свидетельствует о официальном признании его как профессионального игрока."]},
        {"tag":"h2","children":["Заключение"]},
        {"tag":"p","children":["Анарбилег \\"Cobrazera\\" Ууганбаяр представляет собой типичный пример молодого таланта из развивающегося киберспортивного региона. Его переход в The MongolZ и стабильные выступления на турнирах показывают серьезный подход к карьере. В возрасте 19 лет он уже имеет опыт выступлений на международных турнирах и продолжает развиваться как игрок."]},
        {"tag":"p","children":["Монгольская сцена CS2 активно развивается, и такие игроки как Cobrazera являются ее будущим. Его карьера только начинается, и в ближайшие годы мы можем ожидать от него более значительных достижений на мировой арене."]},
        {"tag":"hr"},
        {"tag":"p","children":[{"tag":"em","children":["Источники: Liquipedia, Esports Earnings, HLTV, Championat.com"]}]}
    ]'''
    
    try:
        # Создаем экземпляр издателя
        publisher = TelegraphPublisher(access_token)
        
        # Создаем страницу
        result = publisher.create_page(
            title="Анарбилег 'Cobrazera' Ууганбаяр: Восходящая звезда монгольского CS2",
            content=html_content,
            author_name="Sandbox",
            return_content=True
        )
        
        print("Результат публикации:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        if result.get('ok'):
            page_url = result['result']['url']
            print(f'\n✅ Статья успешно опубликована!')
            print(f'📎 URL: {page_url}')
            print(f'📝 Название: {result["result"]["title"]}')
            print(f'👤 Автор: {result["result"].get("author_name", "Sandbox")}')
        else:
            print(f'\n❌ Ошибка при публикации')
            
    except Exception as e:
        print(f'❌ Ошибка: {e}')

if __name__ == "__main__":
    main()