# API Keys (Hardcoded as requested)
DEEPSEEK_API_KEY = "sk-c4d7d7f6ed1a403f83df8e9c94e24f21"
GROQ_API_KEY = "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"
TELEGRAM_BOT_TOKEN = "8499938548:AAEziitiAxGvl2I5FmKbmRx_QelFVPys10s"
OCR_API_KEY = "K86722958888957"
LANGSEARCH_API_KEY = "sk-7f31d376f2374d28bf1788b8c5e4eb27"
TAVILY_API_KEY = "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"

# Security: List of allowed Telegram User IDs (Integers or Strings)
# Leave empty to ALLOW ALL USERS (Warning: This allows anyone to execute commands on your server)
ALLOWED_USERS = []